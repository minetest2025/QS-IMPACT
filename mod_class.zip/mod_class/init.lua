minetest.register_chatcommand("announce", { 
    params = "<message>",  
    description = "Affiche une annonce en grand à tous les joueurs",  
    privs = {shout = true},  

    func = function(name, message)  
        if message == "" then  
            return false, "Utilisation : /announce <message>"  
        end

        for _, player in pairs(minetest.get_connected_players()) do  
            local player_name = player:get_player_name()  
            minetest.show_formspec(player_name, "announce:message",  
                "size[8,3]" ..  
                "label[1,0.5;" .. minetest.formspec_escape(message) .. "]" .. 
                "button_exit[3,2;2,1;close;Fermer]"  
            )
        end

        minetest.chat_send_all("\xf0\x9f\x93\xa2 Announce by " .. name .. " : " .. message) 
        return true, "Announce send." 
    end
})


shared_chronos = {
    active_chronos = {}, 
    hud_ids = {} 
}


local function format_temps(secondes)
    local minutes = math.floor(secondes / 60)
    local secondes = secondes % 60
    return string.format("%02d:%02d", minutes, secondes)
end


local function update_chronos()
    for owner_name, chrono_data in pairs(shared_chronos.active_chronos) do
        if chrono_data.active and chrono_data.time_remaining > 0 then
            chrono_data.time_remaining = chrono_data.time_remaining - 1
            
            
            for _, player in ipairs(minetest.get_connected_players()) do
                local hud_id = shared_chronos.hud_ids[owner_name.."_"..player:get_player_name()]
                if hud_id then
                    player:hud_change(hud_id, "text", 
                        owner_name..": "..format_temps(chrono_data.time_remaining))
                end
            end
            
        elseif chrono_data.time_remaining <= 0 and chrono_data.active then
            chrono_data.active = false
            minetest.chat_send_all("Chrono ("..owner_name..") is over!")
            
           
            minetest.after(5, function()
                for _, player in ipairs(minetest.get_connected_players()) do
                    local hud_id = shared_chronos.hud_ids[owner_name.."_"..player:get_player_name()]
                    if hud_id then
                        player:hud_remove(hud_id)
                        shared_chronos.hud_ids[owner_name.."_"..player:get_player_name()] = nil
                    end
                end
                shared_chronos.active_chronos[owner_name] = nil
            end)
        end
    end
    
    if next(shared_chronos.active_chronos) ~= nil then 
        minetest.after(1, update_chronos)
    end
end


local function create_hud(owner_name, player)
    local hud_key = owner_name.."_"..player:get_player_name()
    if not shared_chronos.hud_ids[hud_key] then
        shared_chronos.hud_ids[hud_key] = player:hud_add({
            hud_elem_type = "text",
            position = {x = 0.5, y = 0.05},
            offset = {x = 0, y = 20},
            text = owner_name..": "..format_temps(shared_chronos.active_chronos[owner_name].time_remaining),
            alignment = {x = 0, y = -1},
            scale = {x = 100, y = 100},
            number = 0xFF0000,
        })
    end
end


minetest.register_chatcommand("chrono", {
    params = "<secondes>",
    description = "Démarre votre chronomètre visible par tous (ex: /chrono 60)",
    func = function(name, param)
        local temps = tonumber(param)
        
        
        if not temps or temps <= 0 then
            return false, "Usage: /chrono <secondes> (ex: /chrono 120 for 2 minutes)"
        end
        
        
        if shared_chronos.active_chronos[name] then
            shared_chronos.active_chronos[name].active = false
            minetest.after(0.1, function() 
                shared_chronos.active_chronos[name] = {
                    time_remaining = temps,
                    active = true
                }
                
                minetest.chat_send_all(name.." restarted the timer "..format_temps(temps))
                
                
                for _, player in ipairs(minetest.get_connected_players()) do
                    create_hud(name, player)
                end
                
                if not update_chronos_running then
                    update_chronos()
                    update_chronos_running = true
                end
            end)
        else
            shared_chronos.active_chronos[name] = {
                time_remaining = temps,
                active = true
            }
            
            minetest.chat_send_all(name.." started a timer: "..format_temps(temps))
            
            
            for _, player in ipairs(minetest.get_connected_players()) do
                create_hud(name, player)
            end
            
            if not update_chronos_running then
                update_chronos()
                update_chronos_running = true
            end
        end
        
        return true, "Your timer "..format_temps(temps).." has been started!"
    end,
})


minetest.register_on_joinplayer(function(player)
    minetest.after(1, function()
        for owner_name, chrono_data in pairs(shared_chronos.active_chronos) do
            if chrono_data.active then
                create_hud(owner_name, player)
            end
        end
    end)
end)


minetest.register_on_leaveplayer(function(player)
    local player_name = player:get_player_name()
    
    
    for key, _ in pairs(shared_chronos.hud_ids) do
        if string.find(key, "^"..player_name.."_") then
            shared_chronos.hud_ids[key] = nil
        end
    end
    
    
    if shared_chronos.active_chronos[player_name] then
        shared_chronos.active_chronos[player_name] = nil
    end
end)

print("[SharedChronos] Mod chargé avec succès!")


local valid_roles = {
    ["Manager"] = true,
    ["Expert"] = true,
    ["Player"] = true,
    ["Observator"] = true,
    
    
}



local player_roles = {}


minetest.register_entity("mod_class:role_tag", {
    initial_properties = {
        physical = false,
        collide_with_objects = false,
        pointable = false,
        visual = "sprite",
        textures = {"blank.png"},
        visual_size = {x = 0, y = 0},
        is_visible = true,
        glow = 10,
    },

    set_text = function(self, text)
        self.object:set_properties({
            nametag = text,
            nametag_color = "#FFD700"
        })
    end,

    on_activate = function(self)
        self.object:set_armor_groups({immortal = 1})
    end,
})


local function attach_role_tag(player, role)
    
    local objects = minetest.get_objects_inside_radius(player:get_pos(), 2)
    for _, obj in ipairs(objects) do
        if obj and obj:get_luaentity() and obj:get_luaentity().name == "mod_class:role_tag" then
            obj:remove()
        end
    end

    
    local pos = player:get_pos()
    pos.y = pos.y + 2.5

    local obj = minetest.add_entity(pos, "mod_class:role_tag")
    if obj then
        obj:get_luaentity():set_text(role)
        obj:set_attach(player, "", {x = 0, y = 15, z = 0}, {x = 0, y = 0, z = 0})
    end
end


minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    local role = player_roles[name] or "Visitor"
    minetest.after(1, function()
        attach_role_tag(player, role)
    end)
end)


minetest.register_chatcommand("setrole", {
    params = "<joueur> <rôle>",
    description = "Valid role: Manager, Expert, Player, Observator",
    privs = {shout = true},
    func = function(name, param)
        local target, role = param:match("^(%S+)%s+(.+)$")
        if not target or not role then
            return false, "Utilisation : /setrole <name player> <role>"
        end

        if not valid_roles[role] then
            return false, "Invalid role, you have to put : Manager, Expert, Player, Observator"
        end

        local player = minetest.get_player_by_name(target)
        if not player then
            return false, "Player not found."
        end

        player_roles[target] = role
        attach_role_tag(player, role)
        return true, "Player " .. target .. " : '" .. role .. "'."
    end
})

