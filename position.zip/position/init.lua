local json = dofile(minetest.get_modpath("position") .. "/dkjson.lua")

local delay = 1
local timer = 0 
local list_players={}
local list_inventory_players={}
local past_players_qnty = 0

local function dynamicdelay()
    local player_count = #minetest.get_connected_players()
    if player_count-past_players_qnty >= 100 then
        past_players_qnty=player_count
        delay = delay + 0.25
        minetest.log("action", "[DEBUG] Delay increased: " .. delay)
    end
    if player_count / 100 < past_players_qnty / 100 then
        past_players_qnty=player_count
        delay = math.max(1, delay - 0.25)
        minetest.log("action", "[DEBUG] Delay decreased: " .. delay)
    end
end

local function status(player_name, status)
    local data = {
        player_name = player_name,
        status = status
    }

    local json_data = json.encode(data):gsub('"', '\\"')
    local url = "http://127.0.0.1:8080/player_status"
    local command = string.format('curl -X POST -H "Content-Type: application/json" -d "%s" %s', json_data, url)
    os.execute(command)
end

minetest.register_on_leaveplayer(function(player)
    local name = player:get_player_name()
    status(name, "Disconnected")
end)    

minetest.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    status(name, "Online")
end)

local function playerPos(list_players)
    local json_data = json.encode(list_players):gsub('"', '\\"') 

    local url = "http://127.0.0.1:8080/player_positions"

    local command = string.format(
        'curl -s -X POST -H "Content-Type: application/json" -d "%s" %s',
        json_data,
        url
    )
    local result = os.execute(command)
end

local function inventory(list_inventory_players)
    local json_data = json.encode(list_inventory_players):gsub('"', '\\"')

    local url = "http://127.0.0.1:8080/player_inventory"

    local command = string.format(
        'curl -s -X POST -H "Content-Type: application/json" -d "%s" %s',
        json_data,
        url
    )
    local result = os.execute(command)
end

minetest.register_globalstep(function(dtime)
    timer = timer + dtime
    if timer >= delay then
        timer = 0
        for _, player in ipairs(minetest.get_connected_players()) do
            local pos = player:get_pos()
            local player_name = player:get_player_name()
            local inv = player:get_inventory()
            local player_info={
                player_name = player_name,
                x = pos.x,
                z=pos.z,
                health = player:get_hp()
            }
            local player_inventory = {
                player_name = player_name,
                items = {}
            }
            for i = 1, inv:get_size("main") do
                local stack = inv:get_stack("main", i)
                if not stack:is_empty() then
                    table.insert(player_inventory.items, {
                        item_name = stack:get_name(),
                        item_count = stack:get_count(),
                    })
                end
            end
            table.insert(list_players, player_info)
            table.insert(list_inventory_players, player_inventory)
        end
        playerPos(list_players)
        inventory(list_inventory_players)
        dynamicdelay()
        list_players={}
        list_inventory_players={}
    end
end)

local function team(player_name, team)
    local data = {
        player_name = player_name,
        team = team
    }
    local json_data = json.encode(data):gsub('"', '\\"')
    local url = "http://127.0.0.1:8080/team"
    local command = string.format('curl -X POST -H "Content-Type: application/json" -d "%s" %s', json_data, url)
    os.execute(command)
end


minetest.register_chatcommand("team", {
    description = "Choice your team",
    privs = {}, 
    func = function(name, param)
        local number = tonumber(param)
        if number then
            local message = "You are now a member of Team " .. number
            minetest.chat_send_player(name, message) 
            minetest.log("action", name .. " executed /team" .. number)
            team(name, number)
        else
            minetest.chat_send_player(name, "Correct use: /team <number>")
        end
    end
})

minetest.register_chatcommand("leave", {
    description = "Leave any team",
    privs = {}, 
    func = function(name, param)
    local message = "You are no longer part of any team "
    minetest.chat_send_player(name, message) 
    minetest.log("action", name .. " executed /leave")
    team(name, null)
    end
})

minetest.register_chatcommand("inv", {
    params = "<jugador>",
    description = "Muestra el inventario del jugador especificado",
    func = function(name, param)
        local player = minetest.get_player_by_name(param)
        if not player then
            return false, "El jugador no está en línea."
        end

        local inv = player:get_inventory()
        if not inv then
            return false, "No se pudo obtener el inventario del jugador."
        end

        local items = {}
        for i = 1, inv:get_size("main") do
            local stack = inv:get_stack("main", i)
            if not stack:is_empty() then
                table.insert(items, stack:get_count() .. " " .. stack:get_name())
            end
        end

        return true, param .. " tiene: " .. table.concat(items, ", ")
    end
})

local function receive_give_request(data)
    if not (data and data.player_name and data.item and data.quantity) then
        minetest.log("error", "[GIVE] Incomplete data in the request")
        return
    end

    minetest.log("action", "[GIVE] Debug: player_name=" .. data.player_name ..
                               ", item=" .. data.item ..
                               ", quantity=" .. data.quantity)

    local player_name = data.player_name
    local item = data.item
    local quantity = tonumber(data.quantity) or 1

    local params = string.format("%s %s %d", player_name, item, quantity)

    local give_command = minetest.registered_chatcommands["give"]
    if give_command and give_command.func then
        local success, msg = give_command.func("server", params)
        if success then
            minetest.log("action", "[GIVE] Delivered " .. quantity .. " of " .. item .. " to " .. player_name)
        else
            minetest.log("error", "[GIVE] Error executing /give: " .. (msg or "unknown"))
        end
    else
        minetest.log("error", "[GIVE] The /give command is not registered.")
    end
end



local give_timer = 0
local give_poll_delay = 2 

minetest.register_globalstep(function(dtime)
    give_timer = give_timer + dtime
    if give_timer >= give_poll_delay then
        give_timer = 0
        local file_path = minetest.get_modpath("position") .. "/give_request.json"
        local file = io.open(file_path, "r")
        if file then
            local content = file:read("*all")
            file:close()
            if content and content ~= "" then
                local data = json.decode(content)
                if data then
                    receive_give_request(data)
                end
            end
            os.remove(file_path)
        end
    end
end)

-- Este código se ejecutará cuando todos los mods estén cargados
minetest.register_on_mods_loaded(function()
    -- Aquí guardaremos los nombres de todos los ítems
    local items_list = {}

    -- Recorremos la tabla de ítems registrados
    for name, def in pairs(minetest.registered_items) do
        table.insert(items_list, name)
    end

    -- Ejemplo: escribirlos en el archivo items.txt dentro de la carpeta del mundo
    local worldpath = minetest.get_worldpath()
    local file = io.open(worldpath .. "/items.txt", "w")
    if file then
        for _, item_name in ipairs(items_list) do
            file:write(item_name .. "\n")
        end
        file:close()
    end

    -- Mensaje en el log de Minetest para confirmar que se generó el archivo
    minetest.log("action", "[list_items] Se creó la lista de ítems en " .. worldpath .. "/items.txt")
end)
